param([string]$Source, [string]$Target)
$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $PSScriptRoot 'VGAudio.dll')
$audio=[VGAudio.Containers.Hca.HcaReader]::new().ReadFormat([IO.File]::ReadAllBytes($Source)).ToPcm16()
[IO.File]::WriteAllBytes($Target,[VGAudio.Containers.Wave.WaveWriter]::new().GetFile($audio))
